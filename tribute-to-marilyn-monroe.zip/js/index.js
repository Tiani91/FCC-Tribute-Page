$("h1, h2, h3").css("color", "darkgreen");
$("li").css("color", "darkred");
$("h1, h2, h3, p, footer").css("text", "center");
$("h1").css("font-family", "Arial Black", "bold");
$("h2").css("font-family", "gadget");
$("p").css("font-size", "100%", "font-family", "Georgia");
$("body").css("background-color", "lightgrey");